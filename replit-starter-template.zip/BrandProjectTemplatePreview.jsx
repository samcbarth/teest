// Paste your canvas component here (shortened for template)
export default function BrandProjectTemplatePreview() {
  return <div style={{color:'white',background:'#020617',height:'100vh'}}>Starter Loaded</div>;
}

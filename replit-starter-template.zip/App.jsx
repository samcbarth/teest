import BrandProjectTemplatePreview from "./BrandProjectTemplatePreview.jsx";

export default function App() {
  return <BrandProjectTemplatePreview />;
}
